let a="foo";
let aa="bar";
console.log(aa);